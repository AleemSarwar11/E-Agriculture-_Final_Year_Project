module.exports = {
  root: true,
  extends: '@react-native-community/eslint-config',
};
