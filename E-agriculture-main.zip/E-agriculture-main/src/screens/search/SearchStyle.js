import { StyleSheet } from "react-native";
import { Colors } from "../../config/Utils";

 export const SearchStyle = StyleSheet.create({
  root:{
      flex:1,
      backgroundColor:Colors.white
  }
});

