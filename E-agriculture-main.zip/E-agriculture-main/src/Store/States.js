export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const USERDATA = 'USERDATA';
export const WEATHER = 'WEATHER';
export const ALLPRICE = 'ALLPRICE';
export const ALLPRODUCTS = 'ALLPRODUCTS';
export const ALLCROPS = 'ALLCROPS';
export const CHATROOMS = 'CHATROOMS';
