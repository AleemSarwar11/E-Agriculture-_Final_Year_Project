export default {
  // primary: '#5C01E2',
  primary: '#7d5fff',
  black: '#000000',
  secondary: '#fff',
  danger: '#FF6666',
  white: '#FFFFFF',
  lightBlack: '#2E2F33',
  profileCard: '#2F3541',
  success: '#20bf6b',
  drawer: '#E6AC00',

  // #43445B
  //#2B2A3A
};
